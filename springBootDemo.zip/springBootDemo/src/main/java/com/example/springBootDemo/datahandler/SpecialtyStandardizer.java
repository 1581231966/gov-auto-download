package com.example.springBootDemo.datahandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.queryparser.classic.ParseException;

import com.example.springBootDemo.domain.Specialty;

public class SpecialtyStandardizer {
	public static final String DEFAULT_REPLACE_WORD_FILE = "specialty-replace.txt";
	public static final String DEFAULT_STOPWORD_FILE = "specialty-stop.txt";
	
	public static final Map<String, String> REPLACE_DICT;
	public static final String STOP_WORDS;
	
	static {
		REPLACE_DICT = new LinkedHashMap<String, String>();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(SpecialtyStandardizer.class.getResourceAsStream("/" + DEFAULT_REPLACE_WORD_FILE)));
			String st;
			while ((st = br.readLine()) != null) {
				String[] arrSt = st.split("=>");
				REPLACE_DICT.put(arrSt[0].trim(), arrSt[1].trim());
			}
		
		} catch (Exception e) {
	        throw new RuntimeException("Unable to load default replace words");
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		try {
			br = new BufferedReader(
					new InputStreamReader(SpecialtyAnalyzer.class.getResourceAsStream("/" + DEFAULT_STOPWORD_FILE)));
			String st;
			String finalSt = "";
			while ((st = br.readLine()) != null) {
				finalSt = finalSt + st + "|";
			}
			
			if (finalSt.endsWith("|")) {
				finalSt = finalSt.substring(0, finalSt.lastIndexOf("|"));
			}
			STOP_WORDS = finalSt;
		} catch (IOException ex) {
			// default set should always be present as it is part of the
			// distribution (JAR)
			throw new RuntimeException("Unable to load default stopword set");
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static String standardize(String str) {
		String newStr = removeRedunctSpace(str);
		for (String key : REPLACE_DICT.keySet()) {
			String reg = "(?i)\\b(" + key + ")\\b";
			if (key.contains("(")) {
				reg = "(?i)" + key.replace("(", "\\(").replace(")", "\\)");
			}
			if (key.startsWith("&")) {
				reg = "(?i)" + key;
			}
			newStr = newStr.replaceAll(reg, REPLACE_DICT.get(key));
		}
		return newStr.trim();
	}
	
	public static String removeStopwords(String str) {
		if (StringUtils.isEmpty(STOP_WORDS)) {
			return str;
		}
		return str.replaceAll("(?i)\\b(" + STOP_WORDS + ")\\b", "").trim();
	}
	
	public static List<Specialty> normalizeSpecialties(List<Specialty> specialties) {
		List<Specialty> normalizedSpecs = new ArrayList<Specialty>();
		List<String> specsToSkip = new ArrayList<String>();
		for (int i = 0; i < specialties.size(); i ++) {
			Specialty specA = specialties.get(i);
			if (specsToSkip.contains(specA.getStandardSpecialty())) {
				continue;
			}
			
			Specialty specS = new Specialty();
			specS.setStandardSpecialty(specA.getStandardSpecialty());
			specS.addCarrierSpecialties(specA.getCarrierSpecialties());
			for (int j = i + 1; j < specialties.size(); j ++) {
				Specialty specB = specialties.get(j);
				if (ComparatorUtils.getTermsSimilarity(specA.getStandardSpecialty(), specB.getStandardSpecialty()) > 0.8) {
					specS.addCarrierSpecialties(specB.getCarrierSpecialties());
					specsToSkip.add(specB.getStandardSpecialty());
				}
			}
			normalizedSpecs.add(specS);
		}
		return normalizedSpecs;
	}
	
	public static String removeRedunctSpace(String value) {
		return StringUtils.isBlank(value)? value : value.replace("\\s+", " ");
	}
	
	public static String fitString(String value) {
		return StringUtils.isBlank(value) ? value : removeStopwords(value).replace("'s", "").replaceAll("[^a-zA-Z]", " ").replaceAll("\\s+", " ").toLowerCase();
	}
	
    public static void main(String[] args) throws IOException, ParseException {
    	System.out.println(standardize("OBGYN - Obstetrics & Gynecology"));

    	System.out.println(standardize("Family Practice & Osteopathic Manipulative Treatment** since 1999."));
    	System.out.println("Neurological".matches("(?i).*\\b(Neuro.*)\\b"));
    }
}
 