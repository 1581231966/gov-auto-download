package com.example.springBootDemo.domain;

import java.util.List;

import com.example.springBootDemo.datahandler.SpecialtyStandardizer;

public class CarrierSpecialty {
	private String carrierValue;
	private String standardValue;
	private List<String> categories;
	private int termCount;

	public String getCarrierValue() {
		return carrierValue;
	}
	public void setCarrierValue(String carrierValue) {
		this.carrierValue = carrierValue;
	}
	public String getStandardValue() {
		return standardValue;
	}
	public void setStandardValue(String standardValue) {
		this.standardValue = standardValue;
		this.termCount = SpecialtyStandardizer.fitString(standardValue).split(" ").length;
	}
	public List<String> getCategories() {
		return categories;
	}
	public void setCategories(List<String> categories) {
		this.categories = categories;
	}
	public int getTermCount() {
		return termCount;
	}
	public void setTermCount(int termCount) {
		this.termCount = termCount;
	}
}
