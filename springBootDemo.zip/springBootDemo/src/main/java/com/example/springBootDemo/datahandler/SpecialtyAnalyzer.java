package com.example.springBootDemo.datahandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.lucene.analysis.CharArrayMap;
import org.apache.lucene.analysis.CharArraySet;

public final class SpecialtyAnalyzer extends CustomAnalyzer {
	public static final String DEFAULT_STOPWORD_FILE = "specialty-stop.txt";
	public static final String DEFAULT_STEM_DIC_FILE = "specialty-stem-dict.txt";

	public SpecialtyAnalyzer() {
		super(DefaultSetHolder.DEFAULT_STOP_SET, DefaultSetHolder.DEFAULT_STEM_DICT);
	}

	private static class DefaultSetHolder {
		static final CharArraySet DEFAULT_STOP_SET;
		static final CharArrayMap<String> DEFAULT_STEM_DICT;

		static {
			BufferedReader br = null;
			DEFAULT_STOP_SET = new CharArraySet(4, false);
			try {
				br = new BufferedReader(new InputStreamReader(SpecialtyAnalyzer.class.getResourceAsStream("/" + DEFAULT_STOPWORD_FILE)));
				String st;
				while ((st = br.readLine()) != null) {
					DEFAULT_STOP_SET.add(st.trim());
				}

			} catch (IOException ex) {
				// default set should always be present as it is part of the
				// distribution (JAR)
				throw new RuntimeException("Unable to load default stopword set");
			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}

			DEFAULT_STEM_DICT = new CharArrayMap<String>(4, false);
			try {
				br = new BufferedReader(
						new InputStreamReader(SpecialtyAnalyzer.class.getResourceAsStream("/" + DEFAULT_STEM_DIC_FILE)));
				String st;
				while ((st = br.readLine()) != null) {
					String[] arrSt = st.split("=>");
					DEFAULT_STEM_DICT.put(arrSt[0].trim(), arrSt[1].trim());
				}
			} catch (Exception e) {
				throw new RuntimeException("Unable to load default stem dict");
			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
