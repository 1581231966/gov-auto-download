package com.example.springBootDemo.es.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.search.MultiSearchRequest;
import org.elasticsearch.action.search.MultiSearchResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.Operator;
import org.elasticsearch.index.query.PrefixQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.bucket.nested.Nested;
import org.elasticsearch.search.aggregations.bucket.nested.NestedAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.support.ValueType;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.example.springBootDemo.domain.Category;
import com.example.springBootDemo.domain.Specialty;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ElasticSearchHelper {
	@Value("${elasticsearch.provider.index}")
    private String providerIndex;
	@Value("${elasticsearch.category.index}")
    private String categoryIndex;
	@Value("${elasticsearch.global.specialty.index}")
    private String globalSpecialtyIndex;
	
	
	
	private static ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	
	@Autowired
    private ElasticSearchConfiguration elasticSearchClientFactory;

    private SearchResponse sendRequest(SearchRequest searchRequest) {
        SearchResponse response = null;
        try {
            response = elasticSearchClientFactory.getHighLevelClient().search(searchRequest);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }
    
    private MultiSearchResponse sendRequest(MultiSearchRequest msearch) {
    	MultiSearchResponse mresponse = null;
    	try {
    		mresponse = elasticSearchClientFactory.getHighLevelClient().multiSearch(msearch);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return mresponse;
    }

    private SearchRequest getSearchRequest(SearchSourceBuilder sourceBuilder, String indexName) {
        SearchRequest searchRequest = new SearchRequest(indexName);
        searchRequest.source(sourceBuilder);
        return searchRequest;
    }
    
    public List<Category> getCategories() {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.size(100);
        QueryBuilder query= QueryBuilders.matchAllQuery();
        sourceBuilder.query(query);
        
        SearchResponse response = sendRequest(getSearchRequest(sourceBuilder, categoryIndex));
        
        SearchHits searchHits = response.getHits();
        if (searchHits.getHits() == null || searchHits.getHits().length <= 0) {
            return null;
        }
        List<String> objStrs = new ArrayList<String>();
        for (SearchHit searchHit : searchHits) {
            objStrs.add(searchHit.getSourceAsString());
        }
        String hitsSource = "[" + StringUtils.join(objStrs, ",") + "]";
        try {
            return mapper.readValue(hitsSource, mapper.getTypeFactory().constructCollectionType(List.class, Category.class));
        } catch (Exception e) {
        	return null;
        }
    }
    
    public List<Specialty> getGlobalSpecialties() {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.size(10000);
        QueryBuilder query= QueryBuilders.matchAllQuery();
        sourceBuilder.query(query);
        
        SearchResponse response = sendRequest(getSearchRequest(sourceBuilder, globalSpecialtyIndex));
        
        SearchHits searchHits = response.getHits();
        if (searchHits.getHits() == null || searchHits.getHits().length <= 0) {
            return null;
        }
        List<String> objStrs = new ArrayList<String>();
        for (SearchHit searchHit : searchHits) {
            objStrs.add(searchHit.getSourceAsString());
        }
        String hitsSource = "[" + StringUtils.join(objStrs, ",") + "]";
        try {
            return mapper.readValue(hitsSource, mapper.getTypeFactory().constructCollectionType(List.class, Specialty.class));
        } catch (Exception e) {
        	return null;
        }
    }
    
    public List<Specialty> getExactGlobalSpecialties(String specialty) {
    	return getGlobalSpecialties(specialty, Operator.AND, 5);
    }
    
    public List<Specialty> getSimilarGlobalSpecialties(String specialty) {
    	return getGlobalSpecialties(specialty, Operator.OR, 5);
    }
    
    public Map<String, List<Specialty>> getSimilarGlobalSpecialties(List<String> specialties) {
    	return getGlobalSpecialties(specialties, Operator.OR, 10);
    }
    
    public Map<String, List<Specialty>> getGlobalSpecialties(List<String>specialties, Operator operator, int size) {
    	Map<String, List<Specialty>> mapSpecialty = new HashMap<String, List<Specialty>>();
        MultiSearchRequest request = new MultiSearchRequest();
        
        for (String specialty : specialties) {
        	SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
            sourceBuilder.size(size);
            BoolQueryBuilder boolQuery = new BoolQueryBuilder();
            MatchQueryBuilder match = new MatchQueryBuilder("standard_specialty", specialty);
            match.operator(operator);
            boolQuery.must(match);
            sourceBuilder.query(boolQuery);
            
            request.add(getSearchRequest(sourceBuilder, globalSpecialtyIndex));
        }
        
        MultiSearchResponse mresponse = sendRequest(request);
        int i = 0;
        for (MultiSearchResponse.Item item : mresponse) {
        	List<Specialty> specs = new ArrayList<Specialty>();
        	if (!item.isFailure()) {
        		SearchResponse response = item.getResponse();
        		SearchHits searchHits = response.getHits();
                if (searchHits.getHits() != null && searchHits.getHits().length > 0) {
                	List<String> objStrs = new ArrayList<String>();
                    for (SearchHit searchHit : searchHits) {
                        objStrs.add(searchHit.getSourceAsString());
                    }
                    String hitsSource = "[" + StringUtils.join(objStrs, ",") + "]";
                    try {
                    	specs.addAll(mapper.readValue(hitsSource, mapper.getTypeFactory().constructCollectionType(List.class, Specialty.class)));
                    } catch (Exception e) {
                    }
                }
        	}
        	mapSpecialty.put(specialties.get(i), specs);
        	i ++;
        }
    	return mapSpecialty;
    }
    
    public List<Specialty> getGlobalSpecialties(String specialty, Operator operator, int size) {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.size(size);
        BoolQueryBuilder boolQuery = new BoolQueryBuilder();
        MatchQueryBuilder match = new MatchQueryBuilder("standard_specialty", specialty);
        match.operator(operator);
        boolQuery.must(match);
        sourceBuilder.query(boolQuery);
        
        SearchResponse response = sendRequest(getSearchRequest(sourceBuilder, globalSpecialtyIndex));
        
        SearchHits searchHits = response.getHits();
        if (searchHits.getHits() == null || searchHits.getHits().length <= 0) {
            return null;
        }
        List<String> objStrs = new ArrayList<String>();
        for (SearchHit searchHit : searchHits) {
            objStrs.add(searchHit.getSourceAsString());
        }
        String hitsSource = "[" + StringUtils.join(objStrs, ",") + "]";
        try {
            return mapper.readValue(hitsSource, mapper.getTypeFactory().constructCollectionType(List.class, Specialty.class));
        } catch (Exception e) {
        	return null;
        }
    }
    
    public List<String> getSpecialties() {
        SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
        sourceBuilder.size(0);
        
        BoolQueryBuilder boolQuery = new BoolQueryBuilder();
        PrefixQueryBuilder prefixQuery = new PrefixQueryBuilder("carrier_group.carrier_group_name.keyword", "MA_");
        boolQuery.must(prefixQuery);
        
        TermQueryBuilder termQuery = new TermQueryBuilder("is_facility", "N");
        boolQuery.filter(termQuery);
        
        NestedAggregationBuilder nestAgg = new NestedAggregationBuilder("location", "locations");
        TermsAggregationBuilder termAgg = new TermsAggregationBuilder("specialty", ValueType.STRING);
        termAgg.field("locations.specialties.keyword");
        termAgg.size(10000);
        termAgg.order(Terms.Order.term(false));
        nestAgg.subAggregation(termAgg);
        
        sourceBuilder.query(boolQuery);
        sourceBuilder.aggregation(nestAgg);
        
        SearchResponse response = sendRequest(getSearchRequest(sourceBuilder, providerIndex));
        return parseAggSpecialty(response);
    }
    
    private List<String> parseAggSpecialty(SearchResponse response) {
    	List<String> buckets = new ArrayList<String>();
    	if (response.getAggregations() == null) {
    		return buckets;
    	}
    	
    	Nested nested = response.getAggregations().get("location");
    	Terms terms = nested.getAggregations().get("specialty");
    	for (Terms.Bucket bucket : terms.getBuckets()) {
    		buckets.add(bucket.getKey().toString());
    	}
    	return buckets;
    }
}
