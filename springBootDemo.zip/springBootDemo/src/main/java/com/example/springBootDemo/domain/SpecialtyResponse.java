package com.example.springBootDemo.domain;

import java.util.List;

public class SpecialtyResponse {
	private int originalCount;
	private int finalCount;
	private List<Specialty> specialties;
	
	public List<Specialty> getSpecialties() {
		return specialties;
	}
	public void setSpecialties(List<Specialty> specialties) {
		this.specialties = specialties;
	}
	public int getOriginalCount() {
		return originalCount;
	}
	public void setOriginalCount(int originalCount) {
		this.originalCount = originalCount;
	}
	public int getFinalCount() {
		return finalCount;
	}
	public void setFinalCount(int finalCount) {
		this.finalCount = finalCount;
	}
}
