package com.example.springBootDemo.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Specialty {
	@JsonProperty("standard_specialty")
	private String standardSpecialty;
	@JsonProperty("global_specialty")
	private String globalSpecialty;
	@JsonProperty("carrier_specialties")
	private List<String> carrierSpecialties;
	
	public List<String> getCarrierSpecialties() {
		return carrierSpecialties;
	}
	public void setCarrierSpecialties(List<String> carrierSpecialties) {
		this.carrierSpecialties = carrierSpecialties;
	}
	public String getStandardSpecialty() {
		return standardSpecialty;
	}
	public void setStandardSpecialty(String standardSpecialty) {
		this.standardSpecialty = standardSpecialty;
	}
	
	public void addCarrierSpecialty(String carrierSpecialty) {
		if (CollectionUtils.isEmpty(carrierSpecialties)) {
			carrierSpecialties = new ArrayList<String>();
		}
		carrierSpecialties.add(carrierSpecialty);
	}
	
	public void addCarrierSpecialties(List<String> specialties) {
		if (CollectionUtils.isEmpty(carrierSpecialties)) {
			carrierSpecialties = new ArrayList<String>();
		}
		carrierSpecialties.addAll(specialties);
	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof Specialty) {
			Specialty spec = (Specialty) o;
			return this.standardSpecialty.equals(spec.standardSpecialty);
		}
		return super.equals(o);
	}
	public String getGlobalSpecialty() {
		return globalSpecialty;
	}
	public void setGlobalSpecialty(String globalSpecialty) {
		this.globalSpecialty = globalSpecialty;
	}
}
