package com.example.springBootDemo.datahandler;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.lucene.queryparser.classic.ParseException;

public class StandardizerUtils {
	public static Pattern POSSESSIVE_PATTERN = Pattern.compile("'s\\b", Pattern.CASE_INSENSITIVE);
	public static Pattern STOP_PATTERN = Pattern.compile("\\b(and|the|in|w|o)\\b", Pattern.CASE_INSENSITIVE);

	
	public static String removePossesive(String str) {
		if (StringUtils.isBlank(str)) {
			return "";
		}
		
		Matcher matcher = POSSESSIVE_PATTERN.matcher(str);
		StringBuffer sb = new StringBuffer();
		while (matcher.find()) {
			matcher.appendReplacement(sb, "");
		}
		matcher.appendTail(sb);
		return sb.toString().trim();
	}
	
	public static String removeStop(String str) {
		if (StringUtils.isBlank(str)) {
			return "";
		}
		
		Matcher matcher = STOP_PATTERN.matcher(str);
		StringBuffer sb = new StringBuffer();
		while (matcher.find()) {
			matcher.appendReplacement(sb, "");
		}
		matcher.appendTail(sb);
		return sb.toString().trim();
	}
	
	public static String removeRedunctSpace(String value) {
		return StringUtils.isBlank(value)? value : value.replace("\\s+", " ");
	}
	
	public static String fitString(String value) {
		return StringUtils.isBlank(value) ? value : removeStop(removePossesive(value)).replaceAll("[^a-zA-Z]", " ").replaceAll("\\s+", " ");
	}
	
    
    public static void main(String[] args) throws IOException, ParseException {
//    	createIndexForGlobal();
    	System.out.println(fitString("Uro-tewt"));
//    	findAll("carrier");
    }
}
