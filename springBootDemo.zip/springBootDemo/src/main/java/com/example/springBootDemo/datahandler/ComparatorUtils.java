package com.example.springBootDemo.datahandler;

import org.apache.commons.lang3.StringUtils;

public class ComparatorUtils {
	public static boolean isStringSimilar(String str1, String str2) {
		String t1 = StandardizerUtils.fitString(str1).toLowerCase();
		String t2 = StandardizerUtils.fitString(str2).toLowerCase();

		if (isFieldValueEqual(t1, t2)) {
			return true;
		}

		double threshold = getStrictThreshold(Math.max(t1.length(), t2.length()));
		if (getTermsSimilarity(t1, t2) >= threshold)
			return true;
		
		return false;
	}

	public static double getStrictThreshold(int maxLen) {
		if (maxLen <= 6)
			return 0.65;
		if (maxLen > 6 && maxLen <= 9)
			return 0.75;
		return 0.8;
	}

	public static double getStringSimilarity(String s, String t) {
		int ld = StringUtils.getLevenshteinDistance(s, t);
		return 1 - (double) ld / Math.max(s.length(), t.length());
	}
	
	public static boolean isTermsSimilar(String t1, String t2) {
		String[] terms1 = SpecialtyStandardizer.fitString(t1).split(" ");
		String[] terms2 = SpecialtyStandardizer.fitString(t2).split(" ");
		int minLen =  Math.min(terms1.length, terms2.length);
		int maxLen = Math.max(terms1.length, terms2.length);
		
		double threshold = getStrictThreshold(maxLen);
		double similarity = getTermsSimilarity(t1, t2);
		if (minLen == maxLen && similarity == (maxLen - 1)/maxLen) {
			return false;
		} else if (similarity >= threshold)
			return true;
		
		return false;
	}
	
	public static double getTermsSimilarity(String s1, String s2) {
		String t1 = SpecialtyStandardizer.fitString(s1);
		String t2 = SpecialtyStandardizer.fitString(s2);
		
		if (StringUtils.isEmpty(t1) || StringUtils.isEmpty(t2)) {
			return 0;
		}
		
		String[] terms1 = SpecialtyStandardizer.fitString(t1).split(" ");
		String[] terms2 = SpecialtyStandardizer.fitString(t2).split(" ");
		
		String[] termsTemp;
		if (terms2.length > terms1.length) {
			termsTemp = terms1;
			terms1 = terms2;
			terms2 = termsTemp;
		}
		
		double finalSimilarity = 0;
		for (String term2 : terms2) {
			double similarity = 0;
			for (String term1 : terms1) {
				if (term1.trim().substring(0, 1).equals(term2.trim().substring(0, 1))) {
					if (getStringSimilarity(term1.trim(), term2.trim()) > similarity) {
						similarity = getStringSimilarity(term1.trim(), term2.trim());
					}
				}
			}
			finalSimilarity += similarity / terms1.length;
		}
		return finalSimilarity;
	}
	

	public static boolean isFieldValueEqual(String value1, String value2) {
		if (value1 == null || value2 == null || "".equals(value1) || "".equals(value2)) {
			return false;
		}
		return value1.equalsIgnoreCase(value2);
	}
	
	public static void main(String[] args) {
		System.out.println(getTermsSimilarity("BEHAVIORAL HEALTH CLINIC", "Behavioral Therapy"));
	}
}
