package com.example.springBootDemo.datahandler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.QueryParser.Operator;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import com.example.springBootDemo.domain.CarrierSpecialty;

public class SpecialtyLucene {
	private static final String INDEX_DIR = "D:/project/temp/specialty";
	private static final Analyzer ANALYZER = new SpecialtyAnalyzer();
/*	
    public static void main(String[] args) throws IOException, ParseException {
        // 0. Specify the analyzer for tokenizing text.
        //    The same analyzer should be used for indexing and searching
        Analyzer analyzer = new SpecialtyAnalyzer();

        // 1. create the index
        Directory dir = FSDirectory.open(Paths.get(INDEX_DIR));

        IndexWriterConfig config = new IndexWriterConfig(analyzer);

        IndexWriter w = new IndexWriter(dir, config);
        addDoc(w, "Art w sor Therapist");
        addDoc(w, "Art Therapy");
        w.close();

        // 2. query
        String querystr = args.length > 0 ? args[0] : "Therapy";

        // the "title" arg specifies the default field to use
        // when no field is explicitly specified in the query.
        Query q = new QueryParser("title", analyzer).parse(querystr);

        // 3. search
        int hitsPerPage = 10;
        IndexReader reader = DirectoryReader.open(dir);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopDocs docs = searcher.search(q, hitsPerPage);
        ScoreDoc[] hits = docs.scoreDocs;

        // 4. display results
        System.out.println("Found " + hits.length + " hits.");
        for(int i=0;i<hits.length;++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            System.out.println((i + 1) + ". " + d.get("title"));
        }

        // reader can only be closed when there
        // is no need to access the documents any more.
        reader.close();
    } */
    
    public static void main(String[] args) throws IOException, ParseException {
//    	createIndexForGlobal();
    	
    	QueryParser qp = new QueryParser("standard_specialty", ANALYZER);
    	qp.setDefaultOperator(Operator.AND);
        Query q = qp.parse(QueryParser.escape("Otolaryngic Allergy"));
        System.out.println(q.toString());
    }
    
    public static void clearIndices() {
    	deleteIndices(new File(INDEX_DIR));
    }
    
    private static void deleteIndices(File file) {
    	if (file.exists()) {
    		if (file.isFile()) {
    			file.delete();
    		}
    		
    		if (file.isDirectory()) {
    			File files[] = file.listFiles();
    			for (File fileT : files) {
    				deleteIndices(fileT);
    			}
    			file.delete();
    		}
    	}
    }
    
    public static List<CarrierSpecialty> findAll(String indexName) throws IOException {
    	List<CarrierSpecialty> specs = new ArrayList<CarrierSpecialty>();
    	Query q = new MatchAllDocsQuery();
    	Directory dir = FSDirectory.open(Paths.get(INDEX_DIR + File.separator + indexName));
        IndexReader reader = DirectoryReader.open(dir);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopDocs docs = searcher.search(q, 10000);
        ScoreDoc[] hits = docs.scoreDocs;

        // 4. display results
//        System.out.println("Found " + hits.length + " hits.");
        for(int i=0;i<hits.length;++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            CarrierSpecialty cs = new CarrierSpecialty();
            cs.setCarrierValue(d.get("standard_specialty"));
            cs.setStandardValue(SpecialtyStandardizer.standardize(d.get("standard_specialty")));
            specs.add(cs);
        }
        
        reader.close();
        return specs;
    	
    }
    
    public static List<String> findSpecialties(String querystr, String indexName) throws ParseException, IOException {
    	List<String> specs = new ArrayList<String>();
    	
    	QueryParser qp = new QueryParser("standard_specialty", ANALYZER);
    	qp.setDefaultOperator(Operator.AND);
        Query q = qp.parse(QueryParser.escape(querystr));
        
        int hitsPerPage = 20;
        Directory dir = FSDirectory.open(Paths.get(INDEX_DIR + File.separator + indexName));
        IndexReader reader = DirectoryReader.open(dir);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopDocs docs = searcher.search(q, hitsPerPage);
        ScoreDoc[] hits = docs.scoreDocs;

        // 4. display results
//        System.out.println("Found " + hits.length + " hits.");
        for(int i=0;i<hits.length;++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            specs.add(d.get("standard_specialty"));
         
//            System.out.println((i + 1) + ". " + d.get("standard_specialty") + " " + hits[i].score);
        }
        
        reader.close();
        return specs;
    }

    private static void addDoc(IndexWriter w, String str) throws IOException {
        Document doc = new Document();
        doc.add(new TextField("standard_specialty", str, Field.Store.YES));
        w.addDocument(doc);
    }
    
    private static void addDoc(IndexWriter w, List<String> specialties) throws IOException {
    	for (String s : specialties) {
    		Document doc = new Document();
            doc.add(new TextField("standard_specialty", s, Field.Store.YES));
            w.addDocument(doc);
    	}
    }
    
    private static void addDocForCarrierSpecialty(IndexWriter w, List<CarrierSpecialty> specialties) throws IOException {
    	for (CarrierSpecialty s : specialties) {
    		Document doc = new Document();
            doc.add(new TextField("standard_value", s.getStandardValue(), Field.Store.YES));
            doc.add(new StringField("carrier_value", s.getCarrierValue(), Field.Store.YES));
            w.addDocument(doc);
    	}
    }
    
	public static void createIndex(String indexName, List<String> specialties) throws IOException {
        Directory dir = FSDirectory.open(Paths.get(INDEX_DIR + File.separator + indexName));

        IndexWriterConfig config = new IndexWriterConfig(ANALYZER);

        IndexWriter w = new IndexWriter(dir, config);
        addDoc(w, specialties);
        w.close();
	}
    
    public static void createIndexForGlobal() throws IOException {
    	Analyzer analyzer = new SpecialtyAnalyzer();
    	
    	Directory dir = FSDirectory.open(Paths.get(INDEX_DIR + File.separator + "global"));
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        IndexWriter w = new IndexWriter(dir, config);

    	File file = new File("E:\\CategoryMapping\\global.txt");
    	BufferedReader br = new BufferedReader(new FileReader(file));
    	String st;
    	while ((st = br.readLine()) != null) {
    		addDoc(w, st);
    	}
    	w.close();
    	br.close();
    }
    
	public static void createIndexForCarrierSpecialty(String indexName, List<CarrierSpecialty> specialties) throws IOException {
        Directory dir = FSDirectory.open(Paths.get(INDEX_DIR + File.separator + indexName));

        IndexWriterConfig config = new IndexWriterConfig(ANALYZER);

        IndexWriter w = new IndexWriter(dir, config);
        addDocForCarrierSpecialty(w, specialties);
        w.close();
	}
    
    public static List<CarrierSpecialty> findAllCarrierSpecialties(String indexName) throws IOException {
    	List<CarrierSpecialty> specs = new ArrayList<CarrierSpecialty>();
    	Query q = new MatchAllDocsQuery();
    	Directory dir = FSDirectory.open(Paths.get(INDEX_DIR + File.separator + indexName));
        IndexReader reader = DirectoryReader.open(dir);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopDocs docs = searcher.search(q, 10000);
        ScoreDoc[] hits = docs.scoreDocs;

        for(int i=0;i<hits.length;++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            CarrierSpecialty cs = new CarrierSpecialty();
            cs.setCarrierValue(d.get("carrier_value"));
            cs.setStandardValue(d.get("standard_value"));
            specs.add(cs);
        }
        
        reader.close();
        return specs;
    }
    
    public static List<CarrierSpecialty> findCarrierSpecialties(String querystr, String indexName) throws ParseException, IOException {
    	List<CarrierSpecialty> specs = new ArrayList<CarrierSpecialty>();
    	
    	QueryParser qp = new QueryParser("standard_value", ANALYZER);
    	qp.setDefaultOperator(Operator.AND);
        Query q = qp.parse(QueryParser.escape(querystr));
        
        int hitsPerPage = 20;
        Directory dir = FSDirectory.open(Paths.get(INDEX_DIR + File.separator + indexName));
        IndexReader reader = DirectoryReader.open(dir);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopDocs docs = searcher.search(q, hitsPerPage);
        ScoreDoc[] hits = docs.scoreDocs;

        // 4. display results
//        System.out.println("Found " + hits.length + " hits.");
        for(int i=0;i<hits.length;++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            CarrierSpecialty cs = new CarrierSpecialty();
            cs.setCarrierValue(d.get("carrier_value"));
            cs.setStandardValue(d.get("standard_value"));
            specs.add(cs);
        }
        
        reader.close();
        return specs;
    }
}
 