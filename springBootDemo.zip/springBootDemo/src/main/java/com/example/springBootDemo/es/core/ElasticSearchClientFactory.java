package com.example.springBootDemo.es.core;

import java.io.IOException;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.nio.reactor.ConnectingIOReactor;
import org.apache.http.nio.reactor.IOReactorException;
import org.apache.log4j.Logger;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.RestClientBuilder.HttpClientConfigCallback;
import org.elasticsearch.client.RestClientBuilder.RequestConfigCallback;

public class ElasticSearchClientFactory {

    private static final Logger LOGGER = Logger.getLogger(ElasticSearchClientFactory.class.getName());

    private static final int CONNECT_NUMBER = 200;
    private static final int CONNECT_NUMBER_PER_ROUTE = 200;
    private static final int POOL_CONNECT_NUMBER = 200;
    private static final int POOL_CONNECT_NUMBER_PER_ROUTE = 200;
    
    private RestClientBuilder builder;
    private RestHighLevelClient restHighLevelClient;
    
    private static ElasticSearchClientFactory elasticSearchClientFactory = null;

    private ElasticSearchClientFactory() {
    }
    
    public static synchronized ElasticSearchClientFactory getInstance (ElasticSearchEnvironment env){
        if (elasticSearchClientFactory == null) {
            LOGGER.info("init elastic search client factory.");
            elasticSearchClientFactory = new ElasticSearchClientFactory();
            elasticSearchClientFactory.init(env);
        }
        return  elasticSearchClientFactory;
    }

    private void init(ElasticSearchEnvironment env) {
        builder = RestClient.builder(new HttpHost(env.getHost(), env.getPort(), env.getSchema()));
        setConnectTimeOutConfig(env.getConnectTimeout(), env.getSocketTimeout());
        setAysncClientConnectConfig(env.getUserName(), env.getPassword(), CONNECT_NUMBER, CONNECT_NUMBER_PER_ROUTE);
        restHighLevelClient = new RestHighLevelClient(builder);
    }

    //config connection
    private void setConnectTimeOutConfig(int connectTimeout, int socketTimeout) {
        builder.setRequestConfigCallback(new RequestConfigCallback() {

            @Override
            public Builder customizeRequestConfig(Builder requestConfigBuilder) {
                requestConfigBuilder.setConnectTimeout(connectTimeout);
                requestConfigBuilder.setSocketTimeout(socketTimeout);
                requestConfigBuilder.setContentCompressionEnabled(false);
                return requestConfigBuilder;
            }
        }).setMaxRetryTimeoutMillis(socketTimeout);
    }
    
    //config async client
    private void setAysncClientConnectConfig(String userName, String password, int connectNumber, int connectPerRoute) {
        final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY,
                new UsernamePasswordCredentials(userName, password));
        
        builder.setHttpClientConfigCallback(new HttpClientConfigCallback() {
            @Override
            public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpClientBuilder) {
                httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
                httpClientBuilder.setMaxConnTotal(connectNumber);
                httpClientBuilder.setMaxConnPerRoute(connectPerRoute);
                try {
                    ConnectingIOReactor ioReactor = new DefaultConnectingIOReactor();
                    PoolingNHttpClientConnectionManager cm = new PoolingNHttpClientConnectionManager(ioReactor);
                    cm.setMaxTotal(POOL_CONNECT_NUMBER);
                    cm.setDefaultMaxPerRoute(POOL_CONNECT_NUMBER_PER_ROUTE);
                    httpClientBuilder.setConnectionManager(cm);
                } catch (IOReactorException e) {
                    LOGGER.error("init pool error.", e);
                }

                return httpClientBuilder;
            }
        });
    }

    public RestHighLevelClient getHighLevelClient(){
        return restHighLevelClient;
    }

    public void close() {
        if (restHighLevelClient != null) {
            try {
                restHighLevelClient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
}
