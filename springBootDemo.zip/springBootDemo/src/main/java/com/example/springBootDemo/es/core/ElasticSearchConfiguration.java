package com.example.springBootDemo.es.core;

import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ElasticSearchConfiguration {

    @Value("${elasticsearch.client.httpHost.host}")
    private String host;

    @Value("${elasticsearch.client.httpHost.port}")
    private int port;

    @Value("${elasticsearch.client.httpHost.schema}")
    private String schema;

    @Value("${elasticsearch.client.auth.username}")
    private String userName;
    
    @Value("${elasticsearch.client.auth.password}")
    private String password;
    
    @Value("${elasticsearch.client.connect.timeout}")
    private int connectTimeout;
    
    @Value("${elasticsearch.client.socket.timeout}")
    private int socketTimeout;

    @Bean(destroyMethod="close")
    public ElasticSearchClientFactory getFactory() {
        ElasticSearchEnvironment env = new ElasticSearchEnvironment(host, port, schema, userName, password, connectTimeout, socketTimeout);
        return ElasticSearchClientFactory.getInstance(env);
    }

    @Bean
    public RestHighLevelClient getHighLevelClient(){
        return getFactory().getHighLevelClient();
    }
    
    @Bean
    public RestClient getLowLevelClient(){
        return getFactory().getHighLevelClient().getLowLevelClient();
    }
}
