package com.example.springBootDemo.datahandler;

import java.io.IOException;

import org.apache.lucene.analysis.CharArrayMap;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.LowerCaseFilter;
import org.apache.lucene.analysis.StopFilter;
import org.apache.lucene.analysis.StopwordAnalyzerBase;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.en.EnglishPossessiveFilter;
import org.apache.lucene.analysis.en.KStemFilter;
import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
import org.apache.lucene.analysis.miscellaneous.StemmerOverrideFilter;
import org.apache.lucene.analysis.miscellaneous.StemmerOverrideFilter.StemmerOverrideMap;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.standard.StandardFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;
import org.apache.lucene.util.CharsRef;

public class CustomAnalyzer extends StopwordAnalyzerBase {
	  private final CharArraySet stemExclusionSet;
	  private final StemmerOverrideMap stemdict;
	   
	  /**
	   * Returns an unmodifiable instance of the default stop words set.
	   * @return default stop words set.
	   */
	  public static CharArraySet getDefaultStopSet(){
	    return DefaultSetHolder.DEFAULT_STOP_SET;
	  }
	  
	  /**
	   * Atomically loads the DEFAULT_STOP_SET in a lazy fashion once the outer class 
	   * accesses the static final set the first time.;
	   */
	  private static class DefaultSetHolder {
	    static final CharArraySet DEFAULT_STOP_SET = StandardAnalyzer.STOP_WORDS_SET;
	  }

	  /**
	   * Builds an analyzer with the default stop words: {@link #getDefaultStopSet}.
	   */
	  public CustomAnalyzer() {
	    this(DefaultSetHolder.DEFAULT_STOP_SET);
	  }
	  
	  /**
	   * Builds an analyzer with the given stop words.
	   * 
	   * @param stopwords a stopword set
	   */
	  public CustomAnalyzer(CharArraySet stopwords) {
	    this(stopwords, CharArraySet.EMPTY_SET, CharArrayMap.emptyMap());
	  }
	  
	  public CustomAnalyzer(CharArraySet stopwords, CharArrayMap<String> stemOverrideDict) {
		  this(stopwords, CharArraySet.EMPTY_SET, stemOverrideDict);
	  }

	  /**
	   * Builds an analyzer with the given stop words. If a non-empty stem exclusion set is
	   * provided this analyzer will add a {@link SetKeywordMarkerFilter} before
	   * stemming.
	   * 
	   * @param stopwords a stopword set
	   * @param stemExclusionSet a set of terms not to be stemmed
	   */
	  public CustomAnalyzer(CharArraySet stopwords, CharArraySet stemExclusionSet, CharArrayMap<String> stemOverrideDict) {
	    super(stopwords);
	    this.stemExclusionSet = CharArraySet.unmodifiableSet(CharArraySet.copy(stemExclusionSet));
	    if (stemOverrideDict.isEmpty()) {
	        this.stemdict = null;
	      } else {
	        // we don't need to ignore case here since we lowercase in this analyzer anyway
	        StemmerOverrideFilter.Builder builder = new StemmerOverrideFilter.Builder(false);
	        CharArrayMap<String>.EntryIterator iter = stemOverrideDict.entrySet().iterator();
	        while (iter.hasNext()) {
	          char[] nextKey = iter.nextKey();
	          CharsRef spare = new CharsRef(nextKey, 0, nextKey.length);
	          builder.add(spare, iter.currentValue());
	        }
	        try {
	          this.stemdict = builder.build();
	        } catch (IOException ex) {
	          throw new RuntimeException("can not build stem dict", ex);
	        }
	      }
	  }

	@Override
	protected TokenStreamComponents createComponents(String fieldName) {
	    final Tokenizer source = new StandardTokenizer();
	    TokenStream result = new StandardFilter(source);
	    result = new EnglishPossessiveFilter(result);
	    result = new LowerCaseFilter(result);
	    if(!stemExclusionSet.isEmpty())
	      result = new SetKeywordMarkerFilter(result, stemExclusionSet);
	    result = new KStemFilter(result);
	    if(stemdict != null) {
	    	result = new StemmerOverrideFilter(result, stemdict);
	    }
	    result = new StopFilter(result, stopwords);
	    return new TokenStreamComponents(source, result);
	}
}
