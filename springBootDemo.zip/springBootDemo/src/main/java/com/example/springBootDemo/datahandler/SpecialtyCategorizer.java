package com.example.springBootDemo.datahandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.CollectionUtils;

import com.example.springBootDemo.domain.Category;
import com.example.springBootDemo.domain.Specialty;

public class SpecialtyCategorizer {
	private static final String DEFUALT_CATEGORY_FILE = "E:/CategoryMapping/MA_Specialty_Category.xlsx";
	private static final String STANDARD_SPEC_FILE = "E:/CategoryMapping/StandardSpecialty_Final.xlsx";
	private static final ArrayList<Category> CATEGORY_LIST;
	static {
		CATEGORY_LIST = new ArrayList<Category>();
		Workbook wb = null;
		try {
			wb = new XSSFWorkbook(new FileInputStream(DEFUALT_CATEGORY_FILE));
			if (wb != null) {
				Sheet sheet = wb.getSheet("Category");
				Row row;
				for (int r = 4; r < sheet.getPhysicalNumberOfRows(); r ++) {
					row = sheet.getRow(r);
					Category category = new Category();
					category.setCategory(row.getCell(1).getRichStringCellValue().getString());
					
					String premise = row.getCell(3) != null? row.getCell(3).getRichStringCellValue().getString() : "";
					String include = row.getCell(4) != null? row.getCell(4).getRichStringCellValue().getString() : "";
					String exclude = row.getCell(5) != null? row.getCell(5).getRichStringCellValue().getString() : "";
					category.setPremises(splitString(premise));
					category.setIncludes(splitString(include));
					category.setExcludes(splitString(exclude));
					CATEGORY_LIST.add(category);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (wb != null) {
				
				try {
					wb.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void main(String[] args) {
		categorizeSpecialty();
	}
	
	private static final void categorizeSpecialty() {
		List<Specialty> specs = new ArrayList<Specialty>();
		Workbook wb = null;
		try {
			wb = new XSSFWorkbook(new FileInputStream(STANDARD_SPEC_FILE));
			if (wb != null) {
				Sheet sheet = wb.getSheet("Sheet1");
				Row row;
				for (int r = 1; r < sheet.getPhysicalNumberOfRows(); r ++) {
					row = sheet.getRow(r);
					Specialty spec = new Specialty();
					spec.setStandardSpecialty(row.getCell(0).getRichStringCellValue().getString().trim());
					if (specs.contains(spec)) {
						continue;
					}
					specs.add(spec);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (wb != null) {
				try {
					wb.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		List<Category> categories = categorize2(specs);
		File file = new File("E:\\CategoryMapping\\Spec_category.xls");
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		HSSFWorkbook workbook  = null;
		try {
			FileOutputStream fileOut = new FileOutputStream(file);
			workbook = new HSSFWorkbook();
			HSSFSheet worksheet = workbook.createSheet("category");
			HSSFRow r = worksheet.createRow(0);
			Cell c0 = r.createCell(0);
			c0.setCellValue("Category");
			Cell c1 = r.createCell(1);
			c1.setCellValue("StandardSpecialty");
			int rowNum = 1;
			for (int i = 0; i < categories.size(); i ++) {
				r = worksheet.createRow(rowNum);
				String category = categories.get(i).getCategory();
				List<Specialty> specialties = categories.get(i).getSpecialties();
				if (CollectionUtils.isEmpty(specialties)) {
					r.createCell(0).setCellValue(category);
					rowNum ++;
					continue;
				}
				for (int j = 0; j < specialties.size(); j ++) {
					r = worksheet.createRow(rowNum);
					r.createCell(0).setCellValue(category);
					r.createCell(1).setCellValue(specialties.get(j).getStandardSpecialty());
					rowNum ++;
				}
			}
			
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	private static final List<String> splitString(String value) {
		List<String> list = new ArrayList<String>();
		if (StringUtils.isEmpty(value)) {
			return list;
		}
		if (value.endsWith(",")) {
			value = value.substring(0, value.lastIndexOf(",")).trim();
		}
		String[] array = value.split(",");
		for (String a : array) {
			list.add(a.trim());
		}
		return list;
	}
	
	private static final List<Category> initCategories() {
		List<Category> categories = new ArrayList<Category>();
		CATEGORY_LIST.forEach(category -> {
			Category c = new Category();
			c.setCategory(category.getCategory());
			c.setPremises(category.getPremises());
			c.setIncludes(category.getIncludes());
			c.setExcludes(category.getExcludes());
			categories.add(c);
		});
		return categories;
	}
	
	public static final List<Category> categorize(List<Specialty> specialties) {
		Category other = null;
		List<Category> categories = initCategories();
		
    	for (Specialty specialty : specialties) {
    		boolean isMapped = false;
    		
	    	for (Category category : categories) {
	    		if (other == null && category.getCategory().equals("Others")) {
	    			other = category;
	    		}
				boolean require = true;
				boolean include = false;
				boolean exclude = false;
				
	    		String includes = "";
	    		String excludes = "";
	    		String premises = "";
	    		if (!CollectionUtils.isEmpty(category.getIncludes())) {
	    			includes = StringUtils.join(category.getIncludes(), '|');
	    		}
	    		if (!CollectionUtils.isEmpty(category.getExcludes())) {
	    			excludes = StringUtils.join(category.getExcludes(), '|');
	    		}
	    		if (!CollectionUtils.isEmpty(category.getPremises())) {
	    			premises = StringUtils.join(category.getPremises(), '|');
	    		}
	    		
	    		if (StringUtils.isNotEmpty(premises)) {
					if (specialty.getStandardSpecialty().matches("(?i).*\\b(" + premises + ")\\b.*")) {
						require = true;
					} else {
						require = false;
					}
				}
				
				if (StringUtils.isNotEmpty(includes)) {
					if (specialty.getStandardSpecialty().matches("(?i).*\\b(" + includes + ")\\b.*")) {
						include = true;
					} else {
						include = false;
					}
				}
				
				if (StringUtils.isNotEmpty(excludes)) {
					if (specialty.getStandardSpecialty().matches("(?i).*\\b(" + excludes + ")\\b.*")) {
						exclude = true;
					} else {
						exclude = false;
					}
				}
				
				if (require && include && !exclude) {
					category.addSpecialty(specialty);
					isMapped = true;
					break;
				}
	    	}
	    	
	    	if (!isMapped && other != null) {
	    		other.addSpecialty(specialty);
	    	}
    	}
    	
    	return categories;
	}
	
	private static final List<Category> categorize2(List<Specialty> specialties) {
		Category other = null;
		List<Category> categories = initCategories();
		
    	for (Specialty specialty : specialties) {
    		boolean isMapped = false;
    		
	    	for (Category category : categories) {
	    		if (other == null && category.getCategory().equals("Others")) {
	    			other = category;
	    		}
				boolean require = true;
				boolean include = false;
				boolean exclude = false;
				
	    		String includes = "";
	    		String excludes = "";
	    		String premises = "";
	    		if (!CollectionUtils.isEmpty(category.getIncludes())) {
	    			includes = StringUtils.join(category.getIncludes(), '|');
	    		}
	    		if (!CollectionUtils.isEmpty(category.getExcludes())) {
	    			excludes = StringUtils.join(category.getExcludes(), '|');
	    		}
	    		if (!CollectionUtils.isEmpty(category.getPremises())) {
	    			premises = StringUtils.join(category.getPremises(), '|');
	    		}
	    		
	    		if (StringUtils.isNotEmpty(premises)) {
					if (specialty.getStandardSpecialty().matches("(?i).*\\b(" + premises + ")\\b.*")) {
						require = true;
					} else {
						require = false;
					}
				}
				
				if (StringUtils.isNotEmpty(includes)) {
					if (specialty.getStandardSpecialty().matches("(?i).*\\b(" + includes + ")\\b.*")) {
						include = true;
					} else {
						include = false;
					}
				}
				
				if (StringUtils.isNotEmpty(excludes)) {
					if (specialty.getStandardSpecialty().matches("(?i).*\\b(" + excludes + ")\\b.*")) {
						exclude = true;
					} else {
						exclude = false;
					}
				}
				
				if (require && include && !exclude) {
					category.addSpecialty(specialty);
					isMapped = true;
				}
	    	}
	    	
	    	if (!isMapped && other != null) {
	    		other.addSpecialty(specialty);
	    	}
    	}
    	return categories;
	}
	
	public static final List<String> getCategories(String specialty, List<Category> categories) {
		boolean isMapped = false;
		List<String> mapedCategories = new ArrayList<String>();
    	for (Category category : categories) {
			boolean require = true;
			boolean include = false;
			boolean exclude = false;
			
    		String includes = "";
    		String excludes = "";
    		String premises = "";
    		if (!CollectionUtils.isEmpty(category.getIncludes())) {
    			includes = StringUtils.join(category.getIncludes(), '|');
    		}
    		if (!CollectionUtils.isEmpty(category.getExcludes())) {
    			excludes = StringUtils.join(category.getExcludes(), '|');
    		}
    		if (!CollectionUtils.isEmpty(category.getPremises())) {
    			premises = StringUtils.join(category.getPremises(), '|');
    		}
    		
    		if (StringUtils.isNotEmpty(premises)) {
				if (specialty.matches("(?i).*\\b(" + premises + ")\\b.*")) {
					require = true;
				} else {
					require = false;
				}
			}
			
			if (StringUtils.isNotEmpty(includes)) {
				if (specialty.matches("(?i).*\\b(" + includes + ")\\b.*")) {
					include = true;
				} else {
					include = false;
				}
			}
			
			if (StringUtils.isNotEmpty(excludes)) {
				if (specialty.matches("(?i).*\\b(" + excludes + ")\\b.*")) {
					exclude = true;
				} else {
					exclude = false;
				}
			}
			
			if (require && include && !exclude) {
				mapedCategories.add(category.getCategory());
				isMapped = true;
			}
    	}
    	
    	if (!isMapped) {
    		mapedCategories.add("Other");
    	}
    	
    	return mapedCategories;
	}
}
