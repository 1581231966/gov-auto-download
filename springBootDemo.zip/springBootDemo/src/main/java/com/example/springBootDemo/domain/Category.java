package com.example.springBootDemo.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Category {
	private String category;
	private List<String> premises;
	private List<String> includes;
	private List<String> excludes;
	private List<Specialty> specialties;
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public List<String> getPremises() {
		return premises;
	}
	public void setPremises(List<String> premises) {
		this.premises = premises;
	}
	public List<String> getIncludes() {
		return includes;
	}
	public void setIncludes(List<String> includes) {
		this.includes = includes;
	}
	public List<String> getExcludes() {
		return excludes;
	}
	public void setExcludes(List<String> excludes) {
		this.excludes = excludes;
	}
	public List<Specialty> getSpecialties() {
		return specialties;
	}
	public void setSpecialties(List<Specialty> specialties) {
		this.specialties = specialties;
	}
	
	public void addSpecialty(Specialty specialty) {
		if (CollectionUtils.isEmpty(specialties)) {
			specialties = new ArrayList<Specialty>();
		}
		specialties.add(specialty);
	}
}
