package com.example.springBootDemo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springBootDemo.datahandler.ComparatorUtils;
import com.example.springBootDemo.datahandler.SpecialtyCategorizer;
import com.example.springBootDemo.datahandler.SpecialtyLucene;
import com.example.springBootDemo.datahandler.SpecialtyStandardizer;
import com.example.springBootDemo.domain.CarrierSpecialty;
import com.example.springBootDemo.domain.Category;
import com.example.springBootDemo.domain.Specialty;
import com.example.springBootDemo.domain.SpecialtyResponse;
import com.example.springBootDemo.es.core.ElasticSearchHelper;

@RestController
@RequestMapping("/api")
public class HelloWorldController {
	@Autowired
	private ElasticSearchHelper esHelper;
	
    @RequestMapping("/hello")
    public String index() {
        return "Hello World";
    }
    
    @RequestMapping("/createIndex")
    public String createIndex() {
    	List<String> specialties = esHelper.getSpecialties();
    	List<CarrierSpecialty> carrierSpecialties = new ArrayList<CarrierSpecialty>();
    	specialties.forEach(specialty -> {
    		CarrierSpecialty cs = new CarrierSpecialty();
    		cs.setCarrierValue(specialty);
    		cs.setStandardValue(SpecialtyStandardizer.standardize(specialty));
    		carrierSpecialties.add(cs);
    	});
    	
    	try {
//    		List<CarrierSpecialty> carrierSpecialties = SpecialtyLucene.findAll("carrier");
    		
        	SpecialtyLucene.clearIndices();
			SpecialtyLucene.createIndexForCarrierSpecialty("carrierSpecialty", carrierSpecialties);
			SpecialtyLucene.createIndexForGlobal();
			
		} catch (IOException e) {
			e.printStackTrace();
			return "Failed";
		}
    	return "OK";
    }
    
    @RequestMapping("/mytest2")
    public List<Category> getMyCategories() {
    	List<Specialty> standardSpecialties = new ArrayList<Specialty>();
    	List<CarrierSpecialty> carrierSpecs = new ArrayList<CarrierSpecialty>();
    	try {
    		carrierSpecs = SpecialtyLucene.findAllCarrierSpecialties("carrierSpecialty");
    		carrierSpecs.sort((s1, s2) -> s2.getTermCount() - s1.getTermCount());
			
			List<String> specsToSkip = new ArrayList<String>();
			for (CarrierSpecialty spec : carrierSpecs) {
				if (specsToSkip.contains(spec.getStandardValue())) {
					continue;
				}
				
				Specialty standardS = new Specialty();
				standardS.setStandardSpecialty(spec.getStandardValue());
				
				List<CarrierSpecialty> finds = SpecialtyLucene.findCarrierSpecialties(spec.getStandardValue(), "carrierSpecialty");
				if (!CollectionUtils.isEmpty(finds)) {
					for (CarrierSpecialty find : finds) {
//						if (finds.size() <= 2 || !specsToSkip.contains(find.getStandardValue()) && ComparatorUtils.getTermsSimilarity(spec.getStandardValue(), find.getStandardValue()) > 0.5) {
						if (!specsToSkip.contains(find.getStandardValue()) ) {
							standardS.addCarrierSpecialty(find.getCarrierValue());
							specsToSkip.add(find.getStandardValue());
						}
					}
				} else {
					standardS.addCarrierSpecialty(spec.getCarrierValue());
				}
				
				String globalStandard = "";
				List<String> globalFinds = SpecialtyLucene.findSpecialties(standardS.getStandardSpecialty(), "global") ;
				if (!CollectionUtils.isEmpty(globalFinds)) {
					double similarity = 0;
					for (String find: globalFinds) {
						if (ComparatorUtils.getTermsSimilarity(find, standardS.getStandardSpecialty()) > similarity) {
							similarity = ComparatorUtils.getTermsSimilarity(find, standardS.getStandardSpecialty());
							globalStandard = find;
						}
					}
				}
				standardS.setGlobalSpecialty(globalStandard);
				if (!CollectionUtils.isEmpty(standardS.getCarrierSpecialties())) {
					standardS.getCarrierSpecialties().sort((s1, s2) -> s1.compareTo(s2));
				}
				standardSpecialties.add(standardS);
			}
			
			standardSpecialties.sort((s1, s2) -> s1.getStandardSpecialty().compareTo(s2.getStandardSpecialty()));
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	return SpecialtyCategorizer.categorize(standardSpecialties);
    }
    
    @RequestMapping("/mytest")
    public SpecialtyResponse getMySpecialties() {
    	List<Specialty> standardSpecialties = new ArrayList<Specialty>();
    	List<CarrierSpecialty> carrierSpecs = new ArrayList<CarrierSpecialty>();
    	try {
    		carrierSpecs = SpecialtyLucene.findAllCarrierSpecialties("carrierSpecialty");
    		
//			SpecialtyLucene.createIndex("carrier2", specialties);
    		carrierSpecs.sort((s1, s2) -> s2.getTermCount() - s1.getTermCount());

    		/*
    		CarrierSpecialty cs = new CarrierSpecialty();
    		cs.setCarrierValue("obstetrics & Gynecology");
    		cs.setStandardValue("obstetrics & Gynecology");
    		carrierSpecs.add(cs);
*/   		
			
			List<String> specsToSkip = new ArrayList<String>();
			for (CarrierSpecialty spec : carrierSpecs) {
				if (specsToSkip.contains(spec.getStandardValue())) {
					continue;
				}
				Specialty standardS = new Specialty();
				standardS.setStandardSpecialty(spec.getStandardValue());
				
				List<CarrierSpecialty> finds = SpecialtyLucene.findCarrierSpecialties(spec.getStandardValue(), "carrierSpecialty");
				if (!CollectionUtils.isEmpty(finds)) {
					for (CarrierSpecialty find : finds) {
//						if (finds.size() <= 2 || !specsToSkip.contains(find.getStandardValue()) && ComparatorUtils.getTermsSimilarity(spec.getStandardValue(), find.getStandardValue()) > 0.5) {
						if (!specsToSkip.contains(find.getStandardValue()) ) {
							standardS.addCarrierSpecialty(find.getCarrierValue());
							specsToSkip.add(find.getStandardValue());
						}
					}
				} else {
					standardS.addCarrierSpecialty(spec.getCarrierValue());
				}
				
				String globalStandard = "";
				List<String> globalFinds = SpecialtyLucene.findSpecialties(standardS.getStandardSpecialty(), "global") ;
				if (!CollectionUtils.isEmpty(globalFinds)) {
					double similarity = 0;
					for (String find: globalFinds) {
						if (ComparatorUtils.getTermsSimilarity(find, standardS.getStandardSpecialty()) > similarity) {
							similarity = ComparatorUtils.getTermsSimilarity(find, standardS.getStandardSpecialty());
							globalStandard = find;
						}
					}
				}
				standardS.setGlobalSpecialty(globalStandard);
				
				standardSpecialties.add(standardS);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
    	
    	SpecialtyResponse response = new SpecialtyResponse();
    	response.setOriginalCount(carrierSpecs.size());
    	response.setFinalCount(standardSpecialties.size());
    	response.setSpecialties(standardSpecialties);
    	return response;
    }
    
    @RequestMapping("/test")
    public SpecialtyResponse getSpecialties() {
    	List<String> specialties = esHelper.getSpecialties();
    	/*
    	List<String> specialties = new ArrayList<String>();
    	specialties.add("Advanced Heart Failure & Transplant Cardiology");
    	specialties.add("Advanced Heart Failure / Transplant Cardiology");
    	specialties.add("Advanced Heart Failure and Transplant Cardiology");
    	specialties.add("Advanced Heart Failure/Transplant Cardiology");
  	
    	specialties.add("Audiologist");
    	specialties.add("Audiology");
 */     	
    	
    	List<Specialty> standardSpecialties = new ArrayList<Specialty>();
    	Map<String, List<Specialty>> mapSpecialty = esHelper.getSimilarGlobalSpecialties(specialties);
    	for (String specialty : mapSpecialty.keySet()) {
    		List<Specialty> standards = mapSpecialty.get(specialty);
    		Specialty standardS = new Specialty();
			standardS.setStandardSpecialty(specialty);
			double similarity = 0;
    		if (!CollectionUtils.isEmpty(standards)) {
    			similarity = 0.8;
    			boolean match = false;
    			for (Specialty standard : standards) {
    				if (ComparatorUtils.getTermsSimilarity(standard.getStandardSpecialty(), specialty) >= similarity) {
    					similarity = ComparatorUtils.getTermsSimilarity(standard.getStandardSpecialty(), specialty);
    					standardS.setStandardSpecialty(standard.getStandardSpecialty());
    					match = true;
    				}
    			}
    			if (!match) {
    				similarity = 0;
    			}
    		}
    		
    		if (standardSpecialties.contains(standardS)) {
    			standardSpecialties.get(standardSpecialties.indexOf(standardS)).addCarrierSpecialty(specialty + " [" + String.valueOf(similarity) + "]");
    		} else {
    			standardS.addCarrierSpecialty(specialty + " [" + String.valueOf(similarity) + "]");
    			standardSpecialties.add(standardS);
    		}
    	}
/*    	
    	for (String specialty : l) {
    		List<Specialty> standards = esHelper.getExactGlobalSpecialties(specialty);
    		Specialty standardS = null;
    		if (CollectionUtils.isEmpty(standards)) {
    			standards = esHelper.getSimilarGlobalSpecialties(specialty);
    		}
    		if (CollectionUtils.isEmpty(standards)) {
    			standardS = new Specialty();
    			standardS.setStandardSpecialty(specialty);
    		} else {
    			double similarity = 0;
    			for (Specialty standard : standards) {
    				if (ComparatorUtils.getStringSimilarity(standard.getStandardSpecialty(), specialty) > similarity) {
    					similarity = ComparatorUtils.getStringSimilarity(standard.getStandardSpecialty(), specialty);
    					standardS = standard;
    				}
    			}
    		}
    		
    		if (standardSpecialties.contains(standardS)) {
    			standardSpecialties.get(standardSpecialties.indexOf(standardS)).addCarrierSpecialty(specialty);
    		} else {
    			standardS.addCarrierSpecialty(specialty);
    			standardSpecialties.add(standardS);
    		}
    	}
*/
    	List<Specialty> finalSpec = SpecialtyStandardizer.normalizeSpecialties(standardSpecialties);

    	SpecialtyResponse response = new SpecialtyResponse();
    	response.setOriginalCount(specialties.size());
    	response.setFinalCount(finalSpec.size());
    	response.setSpecialties(finalSpec);
    	return response;
    }
    
    @RequestMapping("/test2")
    public List<Category> getCategories() {
    	List<Category> categories = esHelper.getCategories();
    	List<Specialty> globalSpecialties = esHelper.getGlobalSpecialties();
    	Category other = null;
    	for (Specialty specialty : globalSpecialties) {
    		boolean isMapped = false;
    		
	    	for (Category category : categories) {
	    		if (other == null && category.getCategory().equals("Other")) {
	    			other = category;
	    		}
				boolean require = true;
				boolean include = false;
				boolean exclude = false;
				
	    		String includes = "";
	    		String excludes = "";
	    		String premises = "";
	    		if (!CollectionUtils.isEmpty(category.getIncludes())) {
	    			includes = StringUtils.join(category.getIncludes(), '|');
	    		}
	    		if (!CollectionUtils.isEmpty(category.getExcludes())) {
	    			excludes = StringUtils.join(category.getExcludes(), '|');
	    		}
	    		if (!CollectionUtils.isEmpty(category.getPremises())) {
	    			premises = StringUtils.join(category.getPremises(), '|');
	    		}
	    		
	    		if (StringUtils.isNotEmpty(premises)) {
					if (specialty.getStandardSpecialty().matches("(?i).*\\b(" + premises + ")\\b.*")) {
						require = true;
					} else {
						require = false;
					}
				}
				
				if (StringUtils.isNotEmpty(includes)) {
					if (specialty.getStandardSpecialty().matches("(?i).*\\b(" + includes + ")\\b.*")) {
						include = true;
					} else {
						include = false;
					}
				}
				
				if (StringUtils.isNotEmpty(excludes)) {
					if (specialty.getStandardSpecialty().matches("(?i).*\\b(" + excludes + ")\\b.*")) {
						exclude = true;
					} else {
						exclude = false;
					}
				}
				
				if (require && include && !exclude) {
					category.addSpecialty(specialty);
					isMapped = true;
				}
	    	}
	    	
	    	if (!isMapped && other != null) {
	    		other.addSpecialty(specialty);
	    	}
    	}
    	return categories;
    }
    
    @RequestMapping("/test3")
    public List<Specialty> getGlobalSpecialties() {
    	return esHelper.getGlobalSpecialties();
    }
}
